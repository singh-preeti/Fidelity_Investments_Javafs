package com.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.model.Student;
import com.student.repository.StudentRepository;

@Service
public class StudentService {
   @Autowired
     StudentRepository studentRepository;

    
    // Create
    public Student addStudent(Student student) {
        return studentRepository.save(student);
    }

    // Read all
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    //update students
    public Student updateStudent(Integer id, Student student) {

        Student existingStudent = studentRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Student not found with ID: " + id));

        existingStudent.setName(student.getName());
        existingStudent.setAge(student.getAge());
        existingStudent.setDepartment(student.getDepartment());

        return studentRepository.save(existingStudent);
    }
    
 // Delete student - NEW CODE
    public void deleteStudent(Integer id) {

        Student student = studentRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Student not found with ID: " + id));

        studentRepository.delete(student);
    }
}

