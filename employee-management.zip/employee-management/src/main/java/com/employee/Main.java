package com.employee;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.ApplicationContext;

public class Main {
    public static void main(String[] args) {
       
        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        Employee emp = (Employee) context.getBean("preetii");
        System.out.println(emp);
    }
}