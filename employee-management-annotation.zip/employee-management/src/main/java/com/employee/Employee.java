package com.employee;

import org.springframework.beans.factory.annotation.Autowired;

// POJO class 
// Plain Old Java Object
public class Employee {
  int id;
  String name;
  Address add;
  
  public Employee() {
	super();
	
  }
  public Employee(int id, String name, Address add) {
	super();
	this.id = id;
	this.name = name;
	this.add = add;
  }
  public int getId() {
	return id;
  }
  public void setId(int id) {
	this.id = id;
  }
  public String getName() {
	return name;
  }
  public void setName(String name) {
	this.name = name;
  }
  public Address getAdd() {
	return add;
  }
  @Autowired 
  public void setAdd(Address add) {
	this.add = add;
  }
  @Override
  public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", add=" + add + "]";
  }
  
  
  
  
}
