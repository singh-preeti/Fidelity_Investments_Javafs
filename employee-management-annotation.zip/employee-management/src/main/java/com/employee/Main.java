package com.employee;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
       
        try (ClassPathXmlApplicationContext context =
                     new ClassPathXmlApplicationContext("config.xml")) {
            Employee emp = context.getBean("preetii", Employee.class);
            System.out.println(emp);
        }
    }
}